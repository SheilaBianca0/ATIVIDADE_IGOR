from flask import Flask, render_template, redirect, url_for, session, request
from controllers.questionarioController import questionarioController

app = Flask(__name__)
app.secret_key = 'aaaaa'

rotas_publicas = ["questoes.index", "questoes.verifica"]

@app.before_request
def verificaIdentificacao():
    if request.endpoint in rotas_publicas:
        return
    
    if "email" in session:
       return 
    return redirect(url_for("questoes.index"))



app.register_blueprint(questionarioController)

if __name__ == '__main__':
    app.run(debug = True)