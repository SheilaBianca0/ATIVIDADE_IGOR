from flask import Blueprint, render_template, request, redirect, url_for, session

questionarioController = Blueprint("questoes", __name__)

@questionarioController.route("/")
def index():
    return render_template("index.html")

@questionarioController.route("/verifica", methods = ["POST"])
def verifica():
    email = request.form.get("email")
    nome = request.form["nome"]  

    if nome != "":
         if email.split("@")[1] == "aluno.ifsp.edu.br":
            session["nome"] = nome
            session["email"] = email
            return render_template("questoes.questionario")
    return redirect(url_for("questoes.index"))

@questionarioController.route("/questionario")
def questionario():
       return render_template("questionario.html")
    

@questionarioController.route("/logout")
def logout():
    session.pop("email", None)
    session.pop("nome", None)
    return redirect(url_for("questoes.index"))