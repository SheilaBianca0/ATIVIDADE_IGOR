from flask import Flask, render_template, request, redirect, url_for
from controladores.task_controller import get_tasks, add_task, delete_task, get_task, update_task
from controladores.login_controller import session
app = Flask(__name__) 

@app.route('/')
def indexlogin():
    if 'username' in session:
        return f'Faça seu login, {session["username"]}!'
    return 'Você não está logado!' 

@app.route('/login', methods=['POST', 'GET'])
def login ():
    if request.method == 'POST':
        session['username'] = request.form['username']
        return redirect(url_for('index'))
    return redirect(url_for('login.html'))

@app.route('/Logout')
def logout():
    session.pop('username')

@app.route('/')
def index():
    tasks = get_tasks()
    return render_template('index.html', tasks=tasks)

@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        title = request.form['title']
        add_task(title)
        return redirect(url_for('index'))
    return render_template('add_task.html')

@app.route('/edit/<int:task_id>', methods=['GET', 'POST'])
def edit(task_id):
    task = get_task(task_id)
    if request.method == 'POST':
        new_title = request.form['title']
        update_task(task_id, new_title)
        return redirect(url_for('index'))
    return render_template('edit_task.html', task=task)

@app.route('/delete/<int:task_id>')
def delete(task_id):
    delete_task(task_id)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

