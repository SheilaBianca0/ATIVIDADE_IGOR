class Task:
    def __init__(self, id, title):
        self.id = id
        self.title = title

tasks = []
