from flask import render_template, request, redirect, url_for
from modelos.task import tasks, Task

def get_tasks():
    return tasks

def add_task(title):
    task_id = len(tasks) + 1
    new_task = Task(task_id, title)
    tasks.append(new_task)

def delete_task(task_id):
    global tasks
    tasks = [task for task in tasks if task.id != task_id]

def get_task(task_id):
    return next((task for task in tasks if task.id == task_id), None)

def update_task(task_id, new_title):
    task = get_task(task_id)
    if task:
        task.title = new_title
